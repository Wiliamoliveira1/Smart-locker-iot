import pandas as pd
import cv2
import urllib.request
import numpy as np
import os
from datetime import datetime
import face_recognition
import cairosvg
import io




path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'image_folder')

url = 'http://192.168.1.11/capture'
##'''cam.bmp / cam-lo.jpg /cam-hi.jpg / cam.mjpeg '''
if 'Attendance.csv' in os.listdir(os.path.join(os.getcwd(), 'attendance')):
    print("there iss..")
    file_path = os.path.join('attendance', 'Attendance.csv')
    if os.path.exists(file_path):
        os.remove(file_path)
else:
    df = pd.DataFrame(list())
    df.to_csv(os.path.join('attendance', 'Attendance.csv'))


images = []
classNames = []

myList = os.listdir(path)
print(myList)
for cl in myList:
    curImg = cv2.imread(f'{path}/{cl}')
    images.append(curImg)
    classNames.append(os.path.splitext(cl)[0])
print(classNames)

def load_svg_image(svg_path):
    png_data = cairosvg.svg2png(url=svg_path)
    png_stream = io.BytesIO(png_data)
    svg_img = cv2.imdecode(np.frombuffer(png_stream.read(), np.uint8), 1)
    return svg_img

def findEncodings(images):
    encodeList = []
    for img in images:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encode = face_recognition.face_encodings(img)[0]
        encodeList.append(encode)
    return encodeList


def markAttendance(name):
    file_path = os.path.join('attendance', 'Attendance.csv')
    with open(file_path, 'r+') as f:
        myDataList = f.readlines()
        nameList = []
        for line in myDataList:
            entry = line.split(',')
            nameList.append(entry[0])
            if name not in nameList:
                now = datetime.now()
                dtString = now.strftime('%H:%M:%S')
                f.writelines(f'\n{name},{dtString}')



encodeListKnown = findEncodings(images)
print('Encoding Complete')


while True:
    # ...
    for encodeFace, faceLoc in zip(encodesCurFrame, facesCurFrame):
        # ...
        if matches[matchIndex]:
            # ...

            svg_path = r'C:\Users\pietr\OneDrive\Área de Trabalho\Reconhecimento-facial\Laughing_man.svg'
            svg_img = load_svg_image(svg_path)

            width = abs(x1 - x2)
            height = abs(y1 - y2)
            resized_svg_img = cv2.resize(svg_img, (width, height))

            mask = cv2.cvtColor(resized_svg_img, cv2.COLOR_BGR2GRAY)
            _, mask = cv2.threshold(mask, 1, 255, cv2.THRESH_BINARY_INV)

            roi = img[y1:y2, x1:x2]
            img_bg = cv2.bitwise_and(roi, roi, mask=mask)
            img_fg = cv2.bitwise_and(resized_svg_img, resized_svg_img, mask=cv2.bitwise_not(mask))
            dst = cv2.add(img_bg, img_fg)
            img[y1:y2, x1:x2] = dst

    cv2.imshow('Webcam', img)
    key = cv2.waitKey(5)
    if key == ord('q'):
        break



    cv2.imshow('Webcam', img)
    key = cv2.waitKey(5)
    if key == ord('q'):
        break
cv2.destroyAllWindows()
cv2.imread
